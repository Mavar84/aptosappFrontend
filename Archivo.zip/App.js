import AppNavigator from './navigation/AppNavigator';
export default AppNavigator;
