const CONFIG = {
API_URL: 'https://aptosapp-backend.vercel.app' // raíz de su backend
//API_URL: 'http://localhost:8000' // raíz de su backend
};
export default CONFIG;